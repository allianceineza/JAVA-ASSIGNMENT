/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class question5 {
    public static void maing(String[]args){
    Scanner obj=new Scanner(System.in);
    int num;
    System.out.println("enter number");
   num=obj.nextInt();
   if(num>0){
       System.out.println(num+"is positive");
   }
   else if(num<0){
       System.out.println(num+"is negative");
   }
   else
       System.out.println(num+"is zero");
}
}