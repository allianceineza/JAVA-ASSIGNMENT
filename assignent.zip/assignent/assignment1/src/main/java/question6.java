/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class question6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of rows for the right-angled triangle: ");
        int rows = scanner.nextInt();
        
        
        for (int i = 1; i <= rows; i++) {
            // Print asterisks
            for (int j =i; j >= 1; j--) {
                System.out.print(j);
            }
        
            System.out.println();
        }

        scanner.close();
    }
}
