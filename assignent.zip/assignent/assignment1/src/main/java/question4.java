/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
import java.util.Scanner;
public class question4 {
    public static void main(String[]args){
    Scanner obj= new Scanner(System.in);
    System.out.println("enter num1");
    int num1=obj.nextInt();
    System.out.println("enter num2");
     int num2=obj.nextInt();
    System.out.println("enter num3");
     int num3=obj.nextInt();
     if(num1>num2&&num1>num3){
         System.out.println(num1+"is largest");
     }
    else if(num2>num1&&num2>num3){
         System.out.println(num2+"is largest");
     }
     else
        System.out.println(num3+"is largest");
}
}