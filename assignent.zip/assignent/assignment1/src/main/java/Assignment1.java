/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignment1;

/**
 *
 * @author user
 */
import java.util.Scanner;
public class Assignment1 {

    public static void main(String[] args) {
        int num;
    Scanner obj= new Scanner(System.in);
        System.out.println(" enter number");
        num=obj.nextInt();
        if (num%2==0){
        System.out.print( num+ "" +" is even");
        }
        else
        System.out.println(num +""+" is odd");
    }
}
